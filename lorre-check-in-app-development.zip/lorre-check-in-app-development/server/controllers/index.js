module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.ticketController = require('./ticket.controller');
module.exports.checkInController = require('./checkIn.controller');
module.exports.analyticsController = require('./analytics.controller');
module.exports.paymentController = require('./payment.controller');
