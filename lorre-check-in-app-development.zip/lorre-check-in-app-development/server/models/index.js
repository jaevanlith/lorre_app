module.exports.Token = require('./token.model');
module.exports.User = require('./user.model');
module.exports.Ticket = require('./ticket.model');
module.exports.CheckIn = require('./checkIn.model');
module.exports.PaymentData = require('./paymentData.model');
