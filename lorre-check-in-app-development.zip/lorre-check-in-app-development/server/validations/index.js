module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.ticketValidation = require('./ticket.validation');
module.exports.checkInValidation = require('./checkIn.validation');
module.exports.analyticsValidation = require('./analytics.validation');
module.exports.paymentValidation = require('./payment.validation');
